alias ctfr='qjs /bin/hacking/ctfr.js/ctfr.js';
alias auto='qjs /bin/hacking/ctfr.js/auto.js';
alias dath='qjs /bin/hacking/ctfr.js/dath.js';
alias dork='qjs /bin/hacking/ctfr.js/dorks.js';
alias dorks='qjs /bin/hacking/ctfr.js/dorks.js';
alias tgbot='qjs /bin/hacking/Telegram-CLI-Bot/tgbot.js';
alias tmpmail='. /bin/hacking/tmpmail/tmpmail';
