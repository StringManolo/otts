# Add colors before alias
alias ls='ls --color=auto';
alias dir='dir --color=auto';
alias vdir='vdir --color=auto';
alias grep='grep --color=auto';
alias fgrep='fgrep --color=auto';
alias egrep='egrep --color=auto';


# Upload to github
SMBSEGACP() {
  git add --all && git commit -m "$1" && git push
}

# alias
alias l='ls';
alias la='ls -a';
alias v='vim'; # ^X ^E to open command in $EDITOR
alias c='clear' # ^L if you have a command already writen
alias cl='clear && ls'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
alias .....='cd ../../../..'
alias pserv='python -m http.server'
alias gitc='git clone'
alias 775='chmod +775'
alias h='history'
alias myip='curl http://ifconfig.me/ip'
alias quit='exit'
alias q='exit'
alias sb='source ~/.bashrc'
alias gacp='SMBSEGACP'
