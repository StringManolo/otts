# Only run this file if the shell is interactive
case $- in
  *i*) ;;
    *) return;;
esac

# default editor
export EDITOR='vim'

# colors
export red=$'\e[1;31m';
export green=$'\e[1;32m';
export yellow=$'\e[1;33m';
export blue=$'\e[1;34m';
export cyan=$'\e[1;35m';
export white=$'\e[1;37m';
export endc=$'\e[0m';
export lightgray=$'\e[0;37m';
export black=$'\e[0;30m';
export darkgray=$'\e[1;30m';
export darkred=$'\e[0;31m';
export darkgreen=$'\e[0;32m';
export darkyellow=$'\e[0;33m';
export darkblue=$'\e[0;34m';
export magenta=$'\e[0;35m';
export darkcyan=$'\e[0;36m';
export underlinedarkgray=$'\e[0;30m';

# Custom Console
PS1='\n\n${darkblue}otts ${endc}${darkgray}(${blue}$(date +%H${darkgray}:${blue}%M${darkgray}:${blue}%S${darkgray}:${blue}%4N)${darkgray}) ${green}$(pwd)${endc}\n> ';
PS2='${blue}.${endc}  ';



# don't put duplicate lines or lines starting with space in the history.
HISTCONTROL=ignoreboth;

