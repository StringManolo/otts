Hacking Commands:
auto
ctfr
dath
dork
tgbot
